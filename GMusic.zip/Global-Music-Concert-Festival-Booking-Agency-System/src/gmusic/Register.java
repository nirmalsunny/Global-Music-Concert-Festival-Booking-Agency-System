/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gmusic;

import java.sql.*;

/**
 *
 * @author Nirmal Sunny
 */
public class Register {

    private int last_inserted_id;
    
    
  public boolean registration(String title, String type_of_user, String fName, String lName, 
            String address1, String address2, String town, String postCode, 
            String email, String mobileNo, String website, String orgName) throws ClassNotFoundException {
        //this validated data has to be pushed to database
        //set loggedin = 1
        //redirect user to approprite window.
        try { 
            Class.forName("com.mysql.jdbc.Driver");  
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://studentnet.cst.beds.ac.uk/group6","cstmysql56","makeqehi");
                PreparedStatement pstmt = con.prepareStatement("INSERT INTO `customer_details` "
                        + "(`title`, `first_name`, `last_name`, `add_line_1`, `add_line_2`, `town`, `postcode`, `email`, `mobile_number`, `website`, `org_name`)"
                        + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);", Statement.RETURN_GENERATED_KEYS);

            // set the value
            pstmt.setString(1, title);
            pstmt.setString(2, fName);
            pstmt.setString(3, lName);
            pstmt.setString(4, address1);
            pstmt.setString(5, address2);
            pstmt.setString(6, town);
            pstmt.setString(7, postCode);
            pstmt.setString(8, email);
            pstmt.setString(9, mobileNo);
            pstmt.setString(10, website);
            pstmt.setString(11, orgName);//ps limit is 11

            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
                if(rs.next())
                {
                    this.last_inserted_id = rs.getInt(1);
                }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        new RegisterCon(this.last_inserted_id).setVisible(true);
        return true;
        //Main.init();
    }
  
  public boolean registrationCon(String username, String password, String cName, String cardNo, String cvv, String expDate, int lId) throws ClassNotFoundException {
        //this validated data has to be pushed to database
        //set loggedin = 1
        //redirect user to approprite window.
        try{

            Class.forName("com.mysql.jdbc.Driver");  
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://studentnet.cst.beds.ac.uk/group6","cstmysql56","makeqehi");  
            //here sonoo is database name, root is username and password  
            Statement stmt=con.createStatement();  
            stmt.executeUpdate("INSERT INTO `customer_details` (`username`, `password`) VALUES ('" + username + "', '" + password + "');");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        Main.init();
        return true;
        //
    }
}
